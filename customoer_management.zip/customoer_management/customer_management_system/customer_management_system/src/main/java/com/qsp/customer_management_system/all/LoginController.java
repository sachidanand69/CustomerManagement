package com.qsp.customer_management_system.all;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qsp.customer_management_system.dao.CustomerCRUD;
import com.qsp.customer_management_system.dto.Customer;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(req.getParameter("id"));
		String password=req.getParameter("password");
		
		try {
			CustomerCRUD crud=new CustomerCRUD();
			String dbpassword=crud.getPassword(id);
			
			if(dbpassword.equals(password)) {
				
				List<Customer> list=crud.getCustomer();
				
				req.setAttribute("list", list);
				RequestDispatcher dispatcher=req.getRequestDispatcher("home.jsp");
				dispatcher.forward(req, resp);
			}else {
				RequestDispatcher dispatcher=req.getRequestDispatcher("index1.jsp");
				dispatcher.forward(req, resp);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
