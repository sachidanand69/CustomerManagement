package com.qsp.customer_management_system.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.qsp.customer_management_system.dto.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer> {

	@Query("Select c from Customer c Where id=?1 and password=?2")
	Customer findCustomerByIdAndPassword(int id, String password);
	
}
