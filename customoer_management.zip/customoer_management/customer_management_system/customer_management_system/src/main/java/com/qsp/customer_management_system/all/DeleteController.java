package com.qsp.customer_management_system.all;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qsp.customer_management_system.dao.CustomerCRUD;
import com.qsp.customer_management_system.dto.Customer;

@WebServlet("/delete")
public class DeleteController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email=req.getParameter("email");
		CustomerCRUD crud=new CustomerCRUD();
		try {
			int id=crud.findSingleCustomerId(email);
			int count=crud.deleteCustomer(id);
			List<Customer> list=crud.getCustomer();

			req.setAttribute("list", list);
			if(count!=0) {
				RequestDispatcher dispatcher=req.getRequestDispatcher("home.jsp");
				dispatcher.forward(req, resp);
			}else {
				System.out.println("Not deleted");
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
}
