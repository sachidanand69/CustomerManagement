package com.qsp.customer_management_system.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.qsp.customer_management_system.dao.CustomerCRUD;
import com.qsp.customer_management_system.dto.Customer;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@RestController
public class CustomerController extends HttpServlet{

	@Autowired
	private CustomerCRUD crud;
	
	@GetMapping("/getting")
    public List<Customer> getCustomerList() throws Exception{
    	return crud.getCustomer(); 
    }
    
	@PostMapping("/save")
    public String savedCustomer(@RequestBody Customer customer) {
    	Customer cus= crud.savedData(customer);
    	if(cus!=null) {
    		return "saved Data";
    	}
    	else {
    		return "Data Not Saved";
    	}
    }
	
	@GetMapping("/gets")
	public Customer getCustomer(@RequestParam int id, @RequestParam String password) {
		return crud.getCustomerByIdAndPassword(id, password);
	}
	
	
}
