package com.qsp.customer_management_system.all;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qsp.customer_management_system.dao.CustomerCRUD;
import com.qsp.customer_management_system.dto.Customer;

@WebServlet("/search")
public class SearchController extends HttpServlet{
     @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    	// TODO Auto-generated method stub
    	String firstname=req.getParameter("firstname");
    	String email=req.getParameter("email");
    	String phone=req.getParameter("phone");
    	long phone1=0;
    	if(phone!=null) {
    		phone1=Long.parseLong(req.getParameter("phone"));
    	}
    	String city=req.getParameter("city");
    	CustomerCRUD crud=new CustomerCRUD();
    	try {
			  if(firstname!=null) {
				  List<Customer> list=crud.getCustomerByFirstName(firstname);
				  req.setAttribute("list", list);
				  
				  RequestDispatcher dispatcher =req.getRequestDispatcher("home.jsp");
				  dispatcher.forward(req, resp);
				  
			  }else if(email!=null) {
				  List<Customer> list=crud.getCustomerByEmail(email);
				  req.setAttribute("list", list);
				  
				  RequestDispatcher dispatcher =req.getRequestDispatcher("home.jsp");
				  dispatcher.forward(req, resp);
				  
			  }else if(phone1!=0) {
				  List<Customer> list=crud.getCustomerByPhone(phone1);
				  req.setAttribute("list", list);
				  
				  RequestDispatcher dispatcher =req.getRequestDispatcher("home.jsp");
				  dispatcher.forward(req, resp);
				  
			  }else if(city!=null) {
				  List<Customer> list=crud.getCustomerByCity(city);
				  req.setAttribute("list", list);
				  
				  RequestDispatcher dispatcher =req.getRequestDispatcher("home.jsp");
				  dispatcher.forward(req, resp);
			  }
    		
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    }
}
