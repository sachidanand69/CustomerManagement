package com.qsp.customer_management_system.all;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.qsp.customer_management_system.dao.CustomerCRUD;
import com.qsp.customer_management_system.dto.Customer;


@WebServlet("/add")
public class CustomerInsertController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstname=req.getParameter("firstname");
		String lastname=req.getParameter("lastname");
		String city=req.getParameter("city");
		String state=req.getParameter("state");
		String address=req.getParameter("address");
		String email=req.getParameter("email");
		long phone=Long.parseLong(req.getParameter("phone"));
		String password=req.getParameter("password");
		
		Customer customer=new Customer();
		customer.setFirstname(firstname);
		customer.setLastname(lastname);
		customer.setPhone(phone);
		customer.setState(state);
		customer.setCity(city);
		customer.setEmail(email);
		customer.setAddress(address);
		customer.setPassword(password);
		
		CustomerCRUD crud=new CustomerCRUD();
		
		try {
			crud.insertData(customer);
			
			List<Customer> list=crud.getCustomer();
			req.setAttribute("list", list);
			
			RequestDispatcher dispatcher =req.getRequestDispatcher("home.jsp");
			dispatcher.forward(req, resp);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
}
