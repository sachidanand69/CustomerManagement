package com.qsp.customer_management_system.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.customer_management_system.dto.Customer;
import com.qsp.customer_management_system.repo.CustomerRepo;

@Repository
public class CustomerCRUD {

	@Autowired
	private CustomerRepo customerRepo;

	public Connection getConnection() throws Exception {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/customer_management", "root",
				"root");
		return connection;
	}

	public List<Customer> getCustomer() throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER");
		ResultSet rs = preparedStatement.executeQuery();
		List<Customer> list = new ArrayList();
		while (rs.next()) {
			Customer customer = new Customer();
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			list.add(customer);
		}
		return list;
	}

	public Customer savedData(Customer customer) {
		return customerRepo.save(customer);
	}

	public String getPassword(int id) throws Exception {

		Connection connection = getConnection();
		String dbpassword = null;
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT PASSWORD FROM CUSTOMER WHERE ID=?");
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				dbpassword = rs.getString("password");
			}
			connection.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return dbpassword;
	}

	public int insertData(Customer customer) throws Exception {
		Connection connection = getConnection();

		PreparedStatement preparedStatement = connection
				.prepareStatement("INSERT INTO CUSTOMER VALUES(?,?,?,?,?,?,?,?,?)");
		preparedStatement.setInt(1, customer.getId());
		preparedStatement.setString(2, customer.getAddress());
		preparedStatement.setString(3, customer.getCity());
		preparedStatement.setLong(4, customer.getPhone());
		preparedStatement.setString(5, customer.getEmail());
		preparedStatement.setString(6, customer.getFirstname());
		preparedStatement.setString(7, customer.getLastname());
		preparedStatement.setString(8, customer.getPassword());
		preparedStatement.setString(9, customer.getState());
		int count = preparedStatement.executeUpdate();
		connection.close();
		return count;

	}

	public List<Customer> getCustomerByPhone(long phone) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER WHERE PHONE=?");
		preparedStatement.setLong(1, phone);
		ResultSet rs = preparedStatement.executeQuery();
		List<Customer> list = new ArrayList();
		while (rs.next()) {
			Customer customer = new Customer();
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			list.add(customer);
		}
		connection.close();
		return list;
	}

	public List<Customer> getCustomerByFirstName(String name) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER WHERE firstname=?");
		preparedStatement.setString(1, name);
		ResultSet rs = preparedStatement.executeQuery();
		List<Customer> list = new ArrayList();
		while (rs.next()) {
			Customer customer = new Customer();
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			list.add(customer);
		}
		connection.close();
		return list;
	}

	public List<Customer> getCustomerByCity(String city) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER WHERE CITY=?");
		preparedStatement.setString(1, city);
		ResultSet rs = preparedStatement.executeQuery();
		List<Customer> list = new ArrayList();
		while (rs.next()) {
			Customer customer = new Customer();
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			list.add(customer);
		}
		connection.close();
		return list;
	}

	public List<Customer> getCustomerByEmail(String email) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER WHERE EMAIL=?");
		preparedStatement.setString(1, email);
		ResultSet rs = preparedStatement.executeQuery();
		List<Customer> list = new ArrayList();
		while (rs.next()) {
			Customer customer = new Customer();
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			list.add(customer);
		}
		connection.close();
		return list;
	}

	public Customer findSingleCustomer(String email) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM CUSTOMER WHERE EMAIL=?");
		preparedStatement.setString(1, email);
		ResultSet rs = preparedStatement.executeQuery();
		Customer customer = new Customer();
		while (rs.next()) {
			customer.setId(rs.getInt("id"));
			customer.setFirstname(rs.getString("firstname"));
			customer.setLastname(rs.getString("lastname"));
			customer.setEmail(rs.getString("email"));
			customer.setAddress(rs.getString("address"));
			customer.setCity(rs.getString("city"));
			customer.setPhone(rs.getLong("phone"));
			customer.setState(rs.getString("state"));
			customer.setPassword(rs.getString("password"));
		}
		connection.close();
		return customer;
	}

	public int updateSingleCustomer(Customer customer,int id) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement(
				"UPDATE CUSTOMER SET ADDRESS=?, CITY=?, PHONE=?, EMAIL=?, FIRSTNAME=?, LASTNAME=?, PASSWORD=?, STATE=? WHERE ID=?");
		preparedStatement.setString(1, customer.getAddress());
		preparedStatement.setString(2, customer.getCity());
		preparedStatement.setLong(3, customer.getPhone());
		preparedStatement.setString(4, customer.getEmail());
		preparedStatement.setString(5, customer.getFirstname());
		preparedStatement.setString(6, customer.getLastname());
		preparedStatement.setString(7, customer.getPassword());
		preparedStatement.setString(8, customer.getState());
		preparedStatement.setInt(9, id);
		int count = preparedStatement.executeUpdate();
		connection.close();
		return count;
	}
	
	public int findSingleCustomerId(String email) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT ID FROM CUSTOMER WHERE EMAIL=?");
		preparedStatement.setString(1, email);
		ResultSet rs =preparedStatement.executeQuery();
		int id=0;
		while(rs.next()) {
			id=rs.getInt("id");
		}
		return id;
	}
	
	public int deleteCustomer(int id) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM CUSTOMER WHERE ID=?");
		preparedStatement.setInt(1, id);
		int count=preparedStatement.executeUpdate();
		connection.close();
		return count;
	}
	
	public Customer getCustomerByIdAndPassword(int id, String password) {
		return customerRepo.findCustomerByIdAndPassword(id, password);
	}
}
